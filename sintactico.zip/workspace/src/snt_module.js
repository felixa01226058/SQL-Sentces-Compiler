function snt(tokenArray){
    
    //Posición en el arreglo de tokens.
    var counterArray=0;
    
    //Tabla de símbolos. Objeto de Javascript (Es como un diccionario)
    var symbolTable = {};
    
    //Símbolos ya usados. Objeto de Javascript (Es como un diccionario)
    var usedSymbols = {};
    
    //Lista de errores en el analizador sintáctico.
    var errors = [];
    //Arreglo de código intermadio
    var code = [];
        
    function create_db(){
        if(exigir('database')){
            identificador();
            if(!exigir(';')){
                errors.push("Syntax Error: Missing semicolon ';'");
            }
        }
        else{
            errors.push('Syntax Error: You missed DATABASE');
        }
    }

    function create_table(){
        if(exigir('table')){
                identificador();
            if(exigir('(')){
                    elementos_tabla();
                if(exigir(')')){
                    if(exigir(';')){
                        code.push(2010);
                    }
                    else{
                        errors.push("Syntax Error: Missing semicolon ';'");
                        
                    }
                }
                else{
                    
                    errors.push("Syntax Error: Missing ')'");
                }
            }
            else{
                
                errors.push("Syntax Error: Missing '('");
            }
        }
        else{
            errors.push("Syntax Error: You missed TABLE");
        }
    }
    
    /* Agrega un identificador a la tabla de símbolos e inserta su ID en el arreglo
     * de código intermedio. Si el identificador ya exixste en la tabla de símbolos 
     * solamente agrega el ID correspondiente al código intermedio.Array.Array
     * Nota: El ID está compuesto por una 's' y un número.
     */
    function identificador(){
        if(tokenArray[counterArray].type == 'identifier'){
            var value = tokenArray[counterArray].value;
            //Buscar el identificador en la tabla de símbolos.
            //var index = symbolTable.findIndex(function(token) {return token.value == this.value && token.type == this.type;}, value);
            
            //Checar si el identificador ya está en la tabla de símbolos
            if(!usedSymbols[value]){
                //Agrega ID arreglo de código intermedio
                if(Object.keys(symbolTable).length === undefined){
                    
			        throw new Error('No keys found');
                }
                var indexLabel = 's' + Object.keys(symbolTable).length;
                code.push(indexLabel);
                //Agregar a la tabla de símbolos
                symbolTable[indexLabel] = tokenArray[counterArray];
                usedSymbols[tokenArray[counterArray].value] = indexLabel;
            }else{
                console.log("repetido");
                //Agrega ID arreglo de código intermedio
                code.push(usedSymbols[value]);
            }
            counterArray++;
        }else{
            errors.push("Syntax Error: Identifier expected.");
        }
    }

    
    function elementos_tabla () {
        elemento_tabla();
        elementos_tabla_prima();
    }

    function elementos_tabla_prima(){
        if(verificar(',')){
            exigir(',');
            elemento_tabla();
            elementos_tabla_prima();
        }
    }
    
    function elemento_tabla(){
        if(tokenArray[counterArray].type == 'reserved'){
            console.log("reserved");
            restriccion();
        }else if(tokenArray[counterArray].type == 'identifier'){
            columna();
        }else{
            errors.push("Syntax Error: An identifier or a restriction was expected.")
        }
    }
    
    function restriccion(){
        console.log("restriccion");
        code.push(2101);
    	if(verificar("primary")){
    		primary_key();
    	}else if(verificar("foreign")){
    		foreign_key();
    	}else if(verificar("unique")){
    		unique_key();
    	}else if(verificar("check")){
    		check_constraint();
    	}else{
    	    errors.push("Syntax Error: A constraint was expected: {PRIMARY|UNIQUE|REFERENCES|CHECK}");
    	}
    	code.push(2102);
    }
    
    function foreign_key() {
        code.push(2105);
        if (exigir('foreign')) {
            if (exigir('key')) {
                if (exigir('(')) {
                    listado_identificadores();
                    code.push(2111);
                    if (exigir(')')) {
                        if (exigir('references')) {
                            identificador();
                            if (exigir('(')) {
                                listado_identificadores();
                                if (exigir(')')) {
                                    code.push(2106);
                                }
                                else {
                                    errors.push("error: falta ')'");
                                }
                            }
                            else {
                                errors.push("error: falta '('");
                            }
                        }
                        else {
                            errors.push("error: falta 'references'");
                        }
                    }
                    else {
                        errors.push("error: falta ')'");
                    }
                }
                else {
                    errors.push("error: falta '('");
                }
            }
            else {
                errors.push("error: falta 'key'");
            }
        }
        else {
            errors.push("error: falta 'foreign'");
        }
    }
    
    function unique_key() {
        if (exigir('unique')) {
          code.push(2107);
          if (exigir('(')) {
            listado_identificadores();
            if (exigir (')')) {
                code.push(2108);
            }
            else {
                errors.push("Error: Missing right parenthesis: ')'");
            }
          }
          else {
            errors.push("error: Missing left parenthesis '('");
          }
        }
        else {
          errors.push("Error: Missing keyword: 'unique'");
        }
    }
    
    function primary_key(){
	    if (exigir('primary')) {
            if (exigir('key')) {
        	    code.push(2103);
        	    if(exigir("(")){
                	listado_identificadores();
            	    if(exigir(")")){
            	        code.push(2104);
                    }
                    else{
            	        errors.push("Error: Missing right parenthesis: ')'");
                    }
                }
                else{
        	        errors.push('Error: Missing left parenthesis: "("');
                }
            }
            else{
        	    errors.push('Error: Missing key word: "key"');
            }
        }
        else{
        	errors.push('Error: Missing key word: "primary"');
        }
    }
    
    
    function listado_identificadores(){
	    identificador();
	    listado_identificadores_prima();
    }

    function listado_identificadores_prima(){
    	if(verificar(",")){
    	    exigir(",");
    	    identificador();
    	    listado_identificadores_prima();
        }
    }


    function check_constraint(){
        
	    if(verificar("check")){
	        
	        exigir("check");
	        code.push(2109);
	        identificador();
	        operador_relacional();
	        value_literal();
	        code.push(2110);
        }
        else{
	        errors.push('Error: missing "check"' );
        }
    }
    

    function columna (){
        code.push(2001);
        identificador();
        tipo_datos();
        seccion_varios();
        code.push(2007);
    }

    function tipo_datos(){
        if(verificar('varchar')){
            varchar();
        }
        else if(exigir('bit')){
            code.push(101);
        }
        else if(exigir('int')){
            code.push(102);
        }
        else if(exigir('date')){
            code.push(103);
        }
        else if(exigir('datetime')){
            code.push(104);   
        }
        else if(exigir('time')){
            code.push(105);
        }
        else if(exigir('xml')){
            code.push(106);
        }else{
            errors.push("Syntax Error: A datatype was expected {varchar|bit|int|date|datetime|time|xml}.")
        }
    }
    
    
    function varchar(){
        exigir('varchar');
        code.push(100);
        longitud_cadena();
    }
    
    
    function longitud_cadena(){
        if(verificar('(')){
            exigir('(');
            number();
            if(verificar(')')){
                exigir(')');
            }else {
                 errors.push('Error: missing left parenthesis:")"');
            }
            
        }
        else {
             errors.push('Error: missing right parenthesis: "(" ');
        }
    }
    
    function number(){
        //if(1 <= tokenArray[counterArray].value <= 99){
        if(tokenArray[counterArray].type == "value"){
            if(Object.keys(symbolTable).length === undefined){
                    
			        throw new Error('No keys found');
                }
            console.log('numero');
            var indexLabel = "s" + Object.keys(symbolTable).length;
            code.push(indexLabel);
            symbolTable[indexLabel] = tokenArray[counterArray];
            counterArray++;
        }
        else{
            console.log('Syntax Error: Just numbers between 1 and 99 are accepted.');
        }
    }
    
    /*
     * TODO: Terminar sección de varios
     */
    function seccion_varios(){
        if(constraint()){
            seccion_varios();
        }
    }
    

    /*
     *  TODO: Retirar los "exigir" cuando las funciones de los contraints estén definidas
     */
    function constraint(){
        if(verificar('primary')){
            //exigir('primary');
            PK();
            return true;
        }
        else if(verificar('unique')){
            code.push(2154);
            
            exigir('unique');
            return true;
        }
        else if(verificar('references')){
            code.push(2152);
            exigir('references');
            identificador();
            if(verificar("(")){
                exigir("(");
                identificador();
                if(exigir(")")){
                    code.push(2153);
                    return true;
                }else{
                    return false;
                }
            }
            else{
                return false;
            }
            
        }
        else if(verificar('not')){
            //Excepto este "exigir" TODO: Borrar este comentario
            exigir('not');
            if(exigir("null")){
                code.push(2150);
               
            }else{
                errors.push("Syntax Error: Expected NULL.")
            }
            return true;
        }
        else if(verificar('null')){
            exigir('null');
            code.push(2157);
            
            //null();
            return true;
        }
        else{
            return false;
        }
        
    }
    
    function PK(){
     if(exigir('primary')){
        if(exigir('key')){
            code.push(2151);
            
             } 
             else{
                  console.log('falto la palabra key');
               }
      }else {
            console.log('falto la palabra primary');
        }
    }
    
    
    function NN(){
        if(verificar('not')){
            exigir('not');
            if(exigir('null')){
                code.push(150);
            }
        }
        else{
            if(verificar('null')){
                exigir('null');
                code.push(200);
            }
        }
    }
    
    function create_command(){
        if(exigir("create")){

            if(verificar('database')){
                code.push(1000);
                create_db();
                code.push(1001);
            }
            else{
                if (verificar('table')){
                    code.push(2000);
                    create_table();
                }
                else{
                    errors.push("Syntax Error: You need to have DATABASE or TABLE next to the CREATE");
                    
                }
            }
            
        }
        else{
            errors.push("Syntax Error: Missing CREATE statement.");
        }
         
    }
    
    /**
     * Agrega el código del asterisco
     */
    function asterisk(){
        code.push(116);
    }
    
    function values_selected(){
        if(exigir("*")){
            asterisk();
        }else{
           identifier_list();
        }
    }
    
    /* Listado de identificadores */
    function identifier_list(){
        identificador();

        if(counterArray < tokenArray.length){
            while(verificar(',') || tokenArray[counterArray].type == 'identifier'){
                if(!exigir(',')){
                    errors.push("Syntax Error: Missing comma ','");
                }
    
                identificador();
                
                if(counterArray >= tokenArray.length){
                    break;
                }
            }
        }
    }
    
    /*Checar condición*/
    function condicional(){
        if(verificar("where")){
            //Consumir token
            exigir("where");
            code.push(3500);
            //Checar Identificador
            identificador();
            //Checar operador relacional
            operador_relacional();
            //Checar valor (al parecer diferente a "valor" en la semántica del profe)
            value_literal();
            //Finaliza WHERE
            code.push(3501);
        }
    }
    
    /* Terminal <value literal> */
    function value_literal(){
        if(tokenArray[counterArray].type == 'identifier'){
            identificador();
        }else{
            if(tokenArray[counterArray].type == 'value'){
                
                //Agregar ID al código intermedio
                if(Object.keys(symbolTable).length === undefined){
                    
			        throw new Error('No keys found');
                }
                
                var index = Object.keys(symbolTable).length; // get the number of the next position
                var indexLabel = 's'+ index // transform it into a label
                    
                if(string()){
                    
                    code.push(indexLabel);
                    //Agregar valor a la tabla de símbolos
                    symbolTable[indexLabel] = tokenArray[counterArray];
                    symbolTable[indexLabel].type = 'string';
                    counterArray++;
                    
                }else if(numero()){
                    
                    //Agregar ID al código intermedio
                    var index = Object.keys(symbolTable).length;
                    code.push(indexLabel);
                    //Agregar valor a la tabla de símbolos;
                    symbolTable[indexLabel] = tokenArray[counterArray];
                    symbolTable[indexLabel].type = 'number';
                    counterArray++;
                    
                }
                else{
                    errors.push("Syntax Error: Not a valid value to compare: {string | number}.");
                }
                
            }else{
                errors.push("Syntax Error: An identifier or value was expected.");
            }
        }
    }
    
    /* Checar operador relacional 
    *   Se checa de forma directa si es un operador, de lo contrario salta error.
    */
    function operador_relacional(){
        if(tokenArray[counterArray].type == 'operator'){
            var operator = tokenArray[counterArray].value;
            if(operator == '<'){
                code.push(110);
            }else if(operator == '>'){
                code.push(111);
            }else if(operator == '=='){
                code.push(112);
            }else if(operator == '<='){
                code.push(113);
            }else if(operator == '>='){
                code.push(114);
            }else if(operator == '!='){
                code.push(115);
            }
            counterArray++;
        }else{
            errors.push("Syntax Error: Relational operator {<|>|=|!} expected.");
        }
    }
    
    function select_command(){
        if(exigir('select')){
            code.push(5000);
            values_selected();
            
            if(exigir('from')){
                /*Código del FROM*/
                code.push(5001);
                /* Enlistar identificadores */
                identifier_list();
                /* Checar condiciones */
                condicional();
                if(exigir(';')){
                    /* Finalizar SELECT */
                     code.push(5100);
                }
                else{
                    errors.push("Syntax Error: Missing semicolon ';'");
                }
            }
            else{
                errors.push("Syntax Error: Missing FROM statement.");
            }
        }else{
            errors.push('Syntax Error: Missing SELECT statement.');
        }
    }
    
    /*
    * Insert command
    */
    function insert_command(){
        if(exigir('insert')){
            code.push(3000);
            if(exigir('into')){
               // code.push(3005); no sé si está bien esto
                identificador();
                if(exigir('values')){
                   
                    if(exigir('(')){
                         code.push(2500);     
                        listado_valores();
                        if(exigir(')')){
                            code.push(2501);
                            if(exigir(';')){
                                code.push(3001);
                            }
                            else{
                                errors.push('Syntax Error: Missing semicolon ;');
                            }
                        }
                        else{
                            console.log(tokenArray[counterArray]);
                            errors.push('Syntax Error: Misssing ")" ');
                        }
                    }
                    else{
                        
                        errors.push('Syntax Error: Missing "(" ');
                    }
                }
                else{
                    errors.push('Syntax Error: Missing VALUES statement');
                }
            }
            else{
                errors.push('Syntax Error: Missing INTO statement');
            }
        }
        else{
            errors.push('Syntax Error: Missing INSERT statement');
        }
    }
    
    function listado_valores(){
        
        valor();
        listado_valores_prima();
    }
    
    function listado_valores_prima(){
        if(verificar(',')){
            exigir(',');
            valor();
            listado_valores_prima();
        }
       
    }
    
    /* Checar el tipo de valor que es y se cumple con la sintaxis*/
    function valor(){
        if(Object.keys(symbolTable).length === undefined){
                    
			        throw new Error('No keys found');
                }
        var index =  Object.keys(symbolTable).length;
        var indexLabel = 's' + index;
        if(string() || numero() || numero_decimal()){
            symbolTable[indexLabel] = tokenArray[counterArray];
            counterArray++;
            code.push(indexLabel);
        }  
    }
    
    function string(){
        if(isNaN(tokenArray[counterArray].value)){
            console.log("SI ES UN VALOR");
            return true;
        }
    }
    
    function numero(){
        if(tokenArray[counterArray].type == 'value'){
            return true;
        }
    }
    
    function numero_decimal(){
        if(tokenArray[counterArray].type == 'value'){
            return true;
        }
    }
    
    /*
    * Exigir verifica que el token seleccionado sea el correcto y después
    * pasa al siguiente token en la cola.
    */
    function exigir(expected){
        if(counterArray >= tokenArray.length){
           return false; 
        }
        if(expected == tokenArray[counterArray].value){
            counterArray++;
            return true;
        }
        return false;
    }

    /*
    * Verificar comprueba si el token seleccionado es el esperado, pero no pasa
    * al siguiente token.
    */
    function verificar(expected){
        if(counterArray >= tokenArray.length){
           return false; 
        }
        if(expected == tokenArray[counterArray].value){
            return true;
        }
        return false;
    }
        
    
    /*-------------------------------- Main --------------------------------- */
 
    if(verificar('create')){
        create_command();
    }
    else{
        if(verificar('insert')){
            insert_command();
        }
        else{
            if(verificar('select')){
                select_command();
            }else{
                errors.push("Syntax Error: Missing a valid statement: CREATE, SELECT, INSERT.");
            }
        }
    }
    
    return {
        symbolTable,
        code,
        errors
    };
    
    
    
 }