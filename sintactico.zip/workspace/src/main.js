/*global lex */
/*global snt */
function lex_test(input){
	
	var result = lex(input);
	var tokens = result.tokens;
	var output ="";
	for(var i in tokens){
		output += JSON.stringify(tokens[i]) + "<br>";
	}
	output += "-------------------------------------------------<br>";
	output += "Errors: "+result.number_errors+"<br>";

	for(i in result.errors){
		output += JSON.stringify(result.errors[i]) + "<br>";
	}

	document.getElementById("lex-output").innerHTML= output;
	
	snt_test(tokens);
	
}

function snt_test(input){

	var result = snt(input);
	var symboltable = result.symbolTable;
	
	var output = "<h5> Tabla de Símbolos </h5>"+
	"<table style='width:90%'><tr><th>ID</th><th>Value</th><th>Type</th></tr>";
	
	for(var symbol in symboltable){
		output = output + "<tr><td>" + symbol + "</td><td>" + symboltable[symbol].value +
			"</td><td>" + symboltable[symbol].type + "</td></tr>"
	}
	
	output += "</table>"

	output += "<h5> Código Intermedio </h5> <table style='with:10%'>";
	
	//Obtener el código intermedio resultante del proceso.
	var code = result.code;
	
	/*console.log("symbolTable"); // test outputs  
	console.log(symboltable);
	console.log("code");
	console.log(code);
	
	return;*/
	
	for(var c in code){
		output += "<tr><td>" + code[c] + "<td><tr>";
	}
	
	output += "</table>";

	
	output += "-------------------------------------------------<br>";
	output += "Errors: "+result.number_errors+"<br>";

	for(var i in result.errors){
		output += JSON.stringify(result.errors[i]) + "<br>";
	}
	
	document.getElementById("snt-output").innerHTML= output;
	//send intermediate code to xml processing
	
	intermediateCodeTest(code, symboltable);
	
}

/*
* @name intermediateCodeTest
* @desc go through the code choosing what to do according to 
* http://bit.ly/2fcWnmz and call the corresponding function of 
* wirtexml.js located in path /lib
* @arg code {string array}, intermediate code passed by a sintactic module
* @arg symbolTable {object Object}, symbolTable passed by a sintactic module 
*/

function flushDatabase(){
	
	localStorage.clear(); // cear database
	Materialize.toast('Bye-bye Database!', 4000);// 4000 is the duration of the toast
}

function intermediateCodeTest(code, symbolTable){
	
	
	// mainObjectXml is located in lib/writexml.js
	var databases;
	if(localStorage.getItem("database")){
		var xmlString = localStorage.getItem("database");
		var parser = new DOMParser();
		databases =  parser.parseFromString(xmlString, "text/xml").firstChild;
		
		var foundNodes = databases.getElementsByTagName("name_database");	
		
		/*// nodo.parentNode también nos dará
		console.log("Database:");
		console.log(databases);
		console.log("Found nodes:");
		console.log(foundNodes);
		console.log("Holding database would be");
		var dbXML = foundNodes[0].parentNode.parentNode;
		console.log(dbXML);
		
		console.log("Tables in datbase would be");
		console.log("ESTO ES TABLES " +dbXML.getElementsByTagName("tables")[0].nodeName);
		
		return;*/
	}
	else {
		databases = mainObjectXml(); /*global mainObjectXml*/
	}
	
	this.currentDatabase;
	if(localStorage.getItem("currentdatabase")){
		this.currentDatabase = localStorage.getItem("currentdatabase");
	}
	else {
		this.currentDatabase = "encisco";
	}
	
	this.currentTable;
	if(localStorage.getItem("currenttable")){
		this.currentTable = localStorage.getItem("currenttable");
	}
	else {
		this.currentTable = "";
	}
	
	console.log(databases);
	//return;
	this.i = 0;
	var exit = 0;
	var symbolIndex, symbol,nTablaInsert;
	var db, table, datatype, field, row;
	
	while(this.i < code.length && !exit) {
		/*global execFunctions*/
		
		console.log(this.i);
		console.log("next instruction" + code[this.i])
		console.log(code);
		
		if(execFunctions[code[this.i]]){
			execFunctions[code[this.i]](this, code, symbolTable, databases) ;
		}
	}
	
	console.log("finished processing. Result: ");
	console.log(databases);
	localStorage.setItem("database",  "<databases>" + databases.innerHTML + "</databases>");
	localStorage.setItem("currentdatabase", "encisco");
	
	// dispalyeOutput is located in lib/writexml.js
	displayOutput(databases); /*global displayOutput*/
	
        function resizeTextArea($textarea){
        	
            var hiddenDiv = $('.hiddendiv').first();
            if (!hiddenDiv.length) {
                hiddenDiv = $('<div class="hiddendiv common"></div>');
                $('body').append(hiddenDiv);
            }

            var fontFamily = $textarea.css('font-family');
            var fontSize = $textarea.css('font-size');

            if (fontSize) { hiddenDiv.css('font-size', fontSize); }
            if (fontFamily) { hiddenDiv.css('font-family', fontFamily); }

            if ($textarea.attr('wrap') === "off") {
                hiddenDiv.css('overflow-wrap', "normal")
                    .css('white-space', "pre");
            }

            hiddenDiv.text($textarea.val() + '\n');
            var content = hiddenDiv.html().replace(/\n/g, '<br>');
            hiddenDiv.html(content);


            // When textarea is hidden, width goes crazy.
            // Approximate with half of window size

            if ($textarea.is(':visible')) {
                hiddenDiv.css('width', $textarea.width());
            }
            else {
                hiddenDiv.css('width', $(window).width()/2);
            }

            $textarea.css('height', hiddenDiv.height());
        }

        resizeTextArea($('#xml'));
}



