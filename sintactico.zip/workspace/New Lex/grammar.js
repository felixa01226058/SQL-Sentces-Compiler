/*Gramática del lenguaje
 * Es un arreglo de objetos que tiene información de los tokens o terminales
 * permitidos en el lenguaje como su expresión regular y tipo.
 */
 
 var grammar = [
     {
        name: "SELECT",
        regex: /^select/i,
        type: "command",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "INSERT",
        regex: /^insert/i,
        type: "command",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "CREATE",
        regex: /^create/i,
        type: "command",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "TABLE",
        regex: /^table/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "DATABASE",
        regex: /^database/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "INTO",
        regex: /^into/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "FROM",
        regex: /^from/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "WHERE",
        regex: /^where/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "VALUES",
        regex: /^values/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "NULL",
        regex: /^null/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "VARCHAR",
        regex: /^varchar/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "PRIMARY",
        regex: /^primary/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "UNIQUE",
        regex: /^unique/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "REFERENCES",
        regex: /^references/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "NOT",
        regex: /^not/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "CHECK",
        regex: /^check/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "FOREIGN",
        regex: /^foreign/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "KEY",
        regex: /^key/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "INT",
        regex: /^int/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "BIT",
        regex: /^bit/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "DATE",
        regex: /^date/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "TIME",
        regex: /^time/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "DATETIME",
        regex: /^datetime/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "XML",
        regex: /^xml/i,
        type: "reserved",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "SYMBOLS",
        regex: /(\(|\)|;|,|\*)/i,
        type: "symbol",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "OPERATORS",
        regex: /(==|<=|>=|<|>|!=)/i,
        type: "operator",
        priority: 1,
        lowerCase: true
     },
     
     {
        name: "IDENTIFIER",
        regex: /^([a-zA-Z]){3,10}/i,
        type: "identifier",
        priority: 0,
        lowerCase: true
     },
     
     {
        name: "VALUES",
        regex: /(\"[^\"]*\"|\'[^\'']*\'|\d{1,2})/i,
        type: "value",
        priority: 2,
        lowerCase: true
     }
 ];