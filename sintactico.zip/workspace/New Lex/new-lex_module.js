/*Analizado Léxico V2
 * 
 *
*/


function lex(s, grammar){
    var tokens = [];
    var matches = [];
    var errors = [];
    var original = s;

    //Buscar tokens hasta que la cadena introducida esté vacía.
    while(s.length > 0){
        console.log(s);
        var token = {};
        
        //Buscar todas las coincidencias en la grámatica
        for(var i = 0; i < grammar.length; i++){
            if(s.search(grammar[i].regex) == 0){
                matches.push(i);
            }
        }
        
        //Salir al primer caracter que no cumple con la grámatica y marcar error.
        if(matches.length == 0){
            var error = "Error en col " + (original.search(s[0]) + 1) + 
            ": Caracter'"+s[0]+"' no válido.";
			errors.push(error);
			break;
        }
        
        var word = grammar[matches.pop()];
        
        //Escoger la mejor coincidencia dado dos criterios: Prioridad y tamaño si
        // son de la misma prioridad.
        for(var i = 0, j = 0; i < matches.length; i++){
            j = matches[i];
            if(word.priority == grammar[j].priority){
                if(s.match(word.regex)[0].length < s.match(grammar[j].regex)[0].length){
                    word = grammar[j];
                }
            }else if(word.priority < grammar[j].priority){
                word = grammar[j];
            }
        }
        
        //Crear el nuevo token.
        token.value = s.match(word.regex)[0];
        token.type = word.type;
        
        //Si se desea que el token este minúscula se cambiará a minúscula
        if(word.lowerCase){
            token.value.toLowerCase();
        }
        
        //Sacar de la cadena el token obtenido.
        s = s.replace(word.regex, '');
        
        //Eliminar espacios en blanco extra
        s = s.replace(/^(\s)+/i, '');
        
        //Insertar el nuevo token en el arreglo.
        tokens.push(token);
        
        //Vaciar matches
        matches = [];
    }
    
    //Regresar el resultado.
    return {
        tokens: tokens,
        errors: errors
    }
    
}
